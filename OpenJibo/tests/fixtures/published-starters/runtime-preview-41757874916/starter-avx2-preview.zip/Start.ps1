$ErrorActionPreference = "Stop"
& (Join-Path $PSScriptRoot "scripts/cloud/Invoke-OpenJiboSelfHostedStack.ps1") -RunMigration -Image 'ghcr.io/transcendent-software-llc/openjibo-runtime@sha256:c33cc7c29ff23366fd1cb75d34f86145783246a4911509207f143225198dfc8a'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
