#!/usr/bin/env bash
set -euo pipefail
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$script_dir/scripts/cloud/invoke-openjibo-self-hosted-stack.sh" --run-migration --image 'ghcr.io/transcendent-software-llc/openjibo-runtime@sha256:e624e4b665c671270ce9ce1f7368799c61c6111e2156fd9049fa9845c6a81d5a'
