$ErrorActionPreference = "Stop"
& (Join-Path $PSScriptRoot "scripts/cloud/Invoke-OpenJiboSelfHostedStack.ps1") -RunMigration -Image 'ghcr.io/transcendent-software-llc/openjibo-runtime@sha256:0751de785ba77dd15725ba76ec5cee6c83624b1946c03eab6c212f64205abe92'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
