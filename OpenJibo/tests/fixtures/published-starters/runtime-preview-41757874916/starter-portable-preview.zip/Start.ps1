$ErrorActionPreference = "Stop"
& (Join-Path $PSScriptRoot "scripts/cloud/Invoke-OpenJiboSelfHostedStack.ps1") -RunMigration -Image 'ghcr.io/transcendent-software-llc/openjibo-runtime@sha256:7a6b86f60204c18e97fe870c68f26cb94c52a9c143738b840b937d0fc5956758'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
