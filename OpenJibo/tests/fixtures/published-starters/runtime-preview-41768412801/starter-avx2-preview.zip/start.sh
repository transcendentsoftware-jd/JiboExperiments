#!/usr/bin/env bash
set -euo pipefail
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$script_dir/scripts/cloud/invoke-openjibo-self-hosted-stack.sh" --run-migration --image 'ghcr.io/transcendent-software-llc/openjibo-runtime@sha256:0751de785ba77dd15725ba76ec5cee6c83624b1946c03eab6c212f64205abe92'
