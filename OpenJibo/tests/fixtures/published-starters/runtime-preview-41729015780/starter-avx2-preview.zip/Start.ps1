$ErrorActionPreference = "Stop"
& (Join-Path $PSScriptRoot "scripts/cloud/Invoke-OpenJiboSelfHostedStack.ps1") -RunMigration -Image 'ghcr.io/transcendent-software-llc/openjibo-runtime@sha256:964fc94249f91f9d78dbf6dba2e8bb8c7740de1019772a70e1f01acdec9cf24f'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
