$ErrorActionPreference = "Stop"
& (Join-Path $PSScriptRoot "scripts/cloud/Invoke-OpenJiboSelfHostedStack.ps1") -RunMigration -Image 'ghcr.io/transcendent-software-llc/openjibo-runtime@sha256:be8d1d08825de31f910c7dab78d2f3c779a5b2f8735f6bed83298173a8d12169'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
