# OpenJibo self-hosted starter preview

This is a fresh-install preview bundle. It is not an official signed release,
verified image, updater, or upgrade/restore procedure. The OpenJibo runtime
image is pinned to `ghcr.io/transcendent-software-llc/openjibo-runtime@sha256:964fc94249f91f9d78dbf6dba2e8bb8c7740de1019772a70e1f01acdec9cf24f`. A digest identifies bytes but does not prove
provenance. Verify the image source, architecture, and included speech model
before using it. PostgreSQL (`postgres:16-alpine`) and the optional smoke image
(`curlimages/curl:8.10.1`) remain tag-based dependencies. The archive itself
contains no container images and Docker will need network access to pull them.
The included MIT license covers this project's files; third-party image and
dependency license notices and an SBOM have not been certified for this preview.

The included `scripts/cloud/backup-self-hosted.py` captures and verifies private
recovery packets with Python 3.9+. Follow `docs/self-hosted-recovery.md` before
an upgrade; rehearse restore into a separate project. It does not perform
automatic restoration or establish upgrade compatibility.

Prerequisites: Docker with Compose v2; Bash plus OpenSSL for the Bash path, or
PowerShell for the Windows path. Extract the archive to a new directory.

1. Run `./scripts/cloud/initialize-openjibo-compose-env.sh` (Bash) or
   `.\scripts\cloud\Initialize-OpenJiboComposeEnv.ps1` (PowerShell) from the
   extracted directory. This creates `.env` with fresh encryption keys. Do not
   hand-copy `.env.example` to `.env`: its encryption values are samples, and
   the initializer preserves an existing `.env` rather than replacing them.
2. Edit `.env` and set `OPENJIBO_POSTGRES_PASSWORD` to a strong, unique password.
   Preserve `.env` securely: changing its encryption keys later can make stored
   data unreadable. Match the prebuilt image's Whisper/model variant to the
   runtime settings you select.
3. Start with the reviewed image explicitly using the bundled entrypoint:

   Bash: `./start.sh`

   PowerShell: `.\Start.ps1`

The entrypoints call the included launchers with the reviewed image digest.
The API binds only to 127.0.0.1:8080 on the host, and PostgreSQL has no host
port mapping. For a physical robot on your LAN, deliberately change the API
port binding and firewall it for trusted clients; never expose this HTTP
preview publicly. The launcher checks Compose configuration, pulls a missing
pinned image, and applies migrations before the API starts. Do not use this
preview bundle on an existing installation: existing volumes and `.env` require
a release-specific backup, migration, and restore plan. PostgreSQL initialization
only acts on a fresh database volume.
Never use `docker compose down -v` on data you wish to retain.

`MANIFEST.json` records SHA-256 values for every other archive member. It helps
check archive integrity; it is not a signature or proof of image authenticity.

CPU profile: `avx2`. See `CPU-PROFILE.json`.
An AVX2 image requires x86_64 with AVX, AVX2, BMI2, F16C, FMA and SSE4.2
on the Docker runtime host. Do not infer capabilities from a remote client.
Profile metadata is a publisher declaration, not image verification.
