#!/usr/bin/env bash
set -euo pipefail
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$script_dir/scripts/cloud/invoke-openjibo-self-hosted-stack.sh" --run-migration --image 'ghcr.io/transcendent-software-llc/openjibo-runtime@sha256:7a6b86f60204c18e97fe870c68f26cb94c52a9c143738b840b937d0fc5956758'
